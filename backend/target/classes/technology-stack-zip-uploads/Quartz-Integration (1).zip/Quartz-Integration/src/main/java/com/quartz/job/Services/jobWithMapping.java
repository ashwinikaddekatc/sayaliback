package com.quartz.job.Services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.quartz.job.Entity.Getapis;
import com.quartz.job.Entity.Postapis;
import com.quartz.job.Entity.SchedulerJobInfo;
import com.quartz.job.Repos.SchedulerRepository;


@RequestMapping("/api")
@Service
public class jobWithMapping {

	@Autowired
	private SchedulerRepository schedulerRepository;
	
	public void getKeysInJsonUsingMaps(String key)
			throws JsonMappingException, JsonProcessingException {
		
        SchedulerJobInfo jobinfo = schedulerRepository.findByJobName(key);

		List<Object> list = new ArrayList<>();

		Map<String, String> param = new HashMap<String, String>();
		Map<String, String> param1 = new HashMap<String, String>();
		Map<String, String> postparam = new HashMap<String, String>();

		List<String> keys = new ArrayList<>();
		String token = callconnector(jobinfo.getSureconnector_name());

		

		int i = 1;

		// CALL GET API
		List<Getapis> gets = jobinfo.getGets();
		for (Getapis get : gets) {
			ResponseEntity<Object> u = GET(get.getGet_api());
			Object object = u.getBody();

			// EXTRACT KEY AND VALUE FROM ARRAY
			ObjectMapper mapper = new ObjectMapper();
			String str = mapper.writeValueAsString(object);

			JsonParser parser = new JsonParser();
			JsonElement element = parser.parse(str);
			JsonObject obj = element.getAsJsonObject();

			// get key from get api
			Set<Map.Entry<String, JsonElement>> entries = obj.entrySet();
			for (Map.Entry<String, JsonElement> entry1 : entries) {

				String key1 = entry1.getKey();
				String string2 = key1.toString();
				String value2 = entry1.getValue().getAsString();

				param.put(i + "." + key1, value2);

			}
			i++;
		}
	
		System.out.println(param);
		String callconnectorforjson = callconnectorforjson(jobinfo.getConnector_name());
		
		JsonParser parser1 = new JsonParser();
		JsonElement element1 = parser1.parse(callconnectorforjson);
		JsonArray Array = element1.getAsJsonArray();
		System.out.println(Array);
		
		for (JsonElement ar : Array) {
			System.out.println(ar); // EXTRACT JSON OBJECT

			JsonObject obj1 = ar.getAsJsonObject();
			String fieldname = obj1.get("fieldname").getAsString();
			
			String mapped_field = obj1.get("mapped_fields").getAsString();
			
			//HERE WE EXTRACT AGAIN KEYS FROM PARAM
			ObjectMapper mapper = new ObjectMapper();
			String str = mapper.writeValueAsString(param);

			JsonParser parser = new JsonParser();
			JsonElement element = parser.parse(str);
			JsonObject obj = element.getAsJsonObject();

			// get key from get api
			Set<Map.Entry<String, JsonElement>> entries = obj.entrySet();
			for (Map.Entry<String, JsonElement> entry1 : entries) {

				String key1 = entry1.getKey();
				String string2 = key1.toString();
				String value2 = entry1.getValue().getAsString();
				
				if (fieldname.equalsIgnoreCase(key1)) {
					postparam.put(mapped_field, value2);
				}
			}	
			
		}
					
		System.out.println(postparam);
		
		List<Postapis> posts = jobinfo.getPosts();
		for(Postapis post:posts) {
		ResponseEntity<Object> res = POST(post.getApi(), postparam, token);
//		System.out.println(res);
		System.out.println("Send Data to insert in portal backend");

		Object body = res.getBody();
		list.add(body);
		}

	

	}

	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return headers;
	}

	public ResponseEntity<Object> GET(String get) {
		RestTemplate restTemplate = new RestTemplate();

		ResponseEntity<Object> u = restTemplate.getForEntity(get, Object.class);

		return u;

	}

	public ResponseEntity<Object> POST(String jobinfo, Object user, String token) {
		RestTemplate restTemplate = new RestTemplate();
		String resourceUrl = jobinfo;
		String token1 = "Bearer " + token;
		HttpHeaders headers = getHeaders();
		headers.set("Authorization", token1);
		HttpEntity<Object> request = new HttpEntity<Object>(user, headers);
		ResponseEntity<Object> res = restTemplate.postForEntity(resourceUrl, request, Object.class);

		return res;

	}

	public ResponseEntity<Object> PUT(String jobinfo, Object user, String token) {
		RestTemplate restTemplate = new RestTemplate();
		String resourceUrl = jobinfo;
		String token1 = "Bearer " + token;
		HttpHeaders headers = getHeaders();
		headers.set("Authorization", token1);
		HttpEntity<Object> request = new HttpEntity<Object>(user, headers);
//		ResponseEntity<Object> res = restTemplate.put(resourceUrl, request, Object.class);
		ResponseEntity<Object> res = restTemplate.exchange(resourceUrl, HttpMethod.PUT, request, Object.class);

		return res;

	}

	public Object DELETE(String url) {
		RestTemplate restTemplate = new RestTemplate();

		restTemplate.delete(url, Object.class);

		return restTemplate;

	}

	// CALL METHOD
	public Object callmethod(String urll, String param, String method, String token) {

		if (method.equalsIgnoreCase("GET")) {
			ResponseEntity<Object> get = GET(urll);
			Object body = get.getBody();
			System.out.println(body);
			return get.getBody();
		}

		else if (method.equalsIgnoreCase("POST")) {
			ResponseEntity<Object> post = POST(urll, param, token);
			Object body = post.getBody();
			System.out.println(body);

			return post.getBody();

		} else if (method.equalsIgnoreCase("PUT")) {
			ResponseEntity<Object> put = PUT(urll, param, token);
			Object body = put.getBody();
			System.out.println(body);

			return put.getBody();

		} else {
			return null;
		}

	}
	
	

//CONNECTOR CALL
	public String callconnector(String name) throws JsonProcessingException {
		RestTemplate restTemplate = new RestTemplate();
		String url = "http://localhost:9191/token/Sure_Connectbyname/" + name;

		ResponseEntity<Object> u = restTemplate.getForEntity(url, Object.class);
		Object object = u.getBody();
//		System.out.println(object);

		ObjectMapper mapper = new ObjectMapper();
		String str = mapper.writeValueAsString(object);
//		System.out.println(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(object));// print
		JsonParser parser = new JsonParser();
		JsonElement element = parser.parse(str);

		JsonObject obj = element.getAsJsonObject();
		JsonElement token = obj.get("access_token");
		System.out.println(token);
		return token.getAsString();
	}
	//CONNECTOR CALL
		public String callconnectorforjson(String name) throws JsonProcessingException {
			RestTemplate restTemplate = new RestTemplate();
			String url = "http://localhost:9192/token/connector/mapping/connectorname/" + name;

			ResponseEntity<Object> u = restTemplate.getForEntity(url, Object.class);
			Object object = u.getBody();
//			System.out.println(object);

			ObjectMapper mapper = new ObjectMapper();
			String str = mapper.writeValueAsString(object);
//			System.out.println(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(object));// print
			JsonParser parser = new JsonParser();
			JsonElement element = parser.parse(str);

			JsonObject obj = element.getAsJsonObject();
			JsonElement connector_json = obj.get("connector_json");
			System.out.println(connector_json);
			return connector_json.getAsString();
		}
	
	
}
