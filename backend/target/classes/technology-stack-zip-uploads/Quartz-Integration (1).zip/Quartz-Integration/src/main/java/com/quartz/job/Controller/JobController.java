package com.quartz.job.Controller;

import java.util.List;

import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.quartz.job.Entity.SchedulerJobInfo;
import com.quartz.job.Services.SchedulerJobService;

@RequestMapping("/sureconnect")
@RestController
public class JobController {

	@Autowired
	private SchedulerJobService jobService;

	// SAVE OR UPDATE A JOB WORKING FOR BOTH
	@PostMapping("/createschedule")
	public void create(@RequestBody SchedulerJobInfo schedule) throws Exception {
		jobService.saveOrUpdate(schedule);

	}

	// UPDATE JOB
	@PostMapping("/updateschedule")
	public void update(@RequestBody SchedulerJobInfo schedule) throws Exception {
		jobService.saveOrUpdate(schedule);

	}

	// PAUSE A JOB
	@PostMapping("/pauseschedule")
	public void NEWJOB(@RequestBody SchedulerJobInfo schedule) throws Exception {
		jobService.pauseJob(schedule);

	}

	// RESUME JOB
	@PostMapping("/resumeschedule")
	public void resume(@RequestBody SchedulerJobInfo schedule) throws Exception {
		jobService.resumeJob(schedule);

	}

	// RUN JOB ONCE
	@PostMapping("/runschedule")
	public void startjob(@RequestBody SchedulerJobInfo schedule) throws Exception {
		jobService.startJobNow(schedule);

	}

	// DELETE JOB
	@DeleteMapping("/deleteschedule/{jobName}")
	public void delete(@PathVariable String jobName, SchedulerJobInfo schedule) throws Exception {
		jobService.deleteJob(jobName, schedule);

	}

	// GET ALL JOB
	@GetMapping("/getalljob")
	public List<SchedulerJobInfo> getall() throws Exception {
		List<SchedulerJobInfo> getall = jobService.getall();
		return getall;

	}

	// GET ALL RUNNING JOB
	@GetMapping("/getallrunning")
	public List<JobExecutionContext> getallrunning() throws Exception {
		List<JobExecutionContext> list = jobService.getallrunning();
		return list;

	}

}
