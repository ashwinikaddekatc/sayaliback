package com.quartz.job.Entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.Data;

@Entity
@Data
public class SchedulerJobInfo {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long jobId;
	
	@Column(unique = true)
    private String jobName; //mandatory
    private String jobGroup;//mandatory
    private String jobStatus;
    private String jobClass;
    private String description; 
    private String interfaceName;
    
    private Long repeatTime;//mandatory
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm")
    private LocalDateTime startTime;//mandatory
    
    private String cronExpression;//mandatory
    private Boolean cronJob;
    
    private String token;
    private String sureconnector_name;
    
    private String connector_name;

    
    
	@JsonManagedReference
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "con",targetEntity = Getapis.class)
    private List<Getapis> gets = new ArrayList<>(); //Mandatory
	
	@JsonManagedReference
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "apiConnection",targetEntity =Postapis.class )
    private List<Postapis> posts; //Mandatory
    //API
    private String get_api; //Mandatory
	private String post_api; //Mandatory
	private String delete_api; //Mandatory
 

}
