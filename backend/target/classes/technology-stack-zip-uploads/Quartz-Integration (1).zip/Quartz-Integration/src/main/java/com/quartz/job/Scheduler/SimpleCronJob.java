package com.quartz.job.Scheduler;

import java.util.stream.IntStream;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.quartz.job.Entity.SchedulerJobInfo;
import com.quartz.job.Services.DataTransferJob;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@DisallowConcurrentExecution
public class SimpleCronJob extends QuartzJobBean {

	@Autowired
	private DataTransferJob jobdet;

	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {

		log.info("SimpleCronJob Start................");
		System.out.println("cron job is running");

		String key = context.getJobDetail().getKey().getName();

		System.out.println("job is : " + key);
		jobdet.dataTransfer(key);

		log.info("SimpleCronJob End................");
	}
}