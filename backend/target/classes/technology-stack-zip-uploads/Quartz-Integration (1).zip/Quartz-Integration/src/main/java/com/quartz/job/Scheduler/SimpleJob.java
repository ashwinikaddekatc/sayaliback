package com.quartz.job.Scheduler;

import java.security.PublicKey;
import java.util.stream.IntStream;

import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.StaticApplicationContext;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.quartz.job.Entity.SchedulerJobInfo;
import com.quartz.job.Services.DataTransferJob;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SimpleJob extends QuartzJobBean {

	@Autowired
	private DataTransferJob jobdet;
	
	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		log.info("Simple Start................");
		System.out.println("simple job is running");

		String key = context.getJobDetail().getKey().getName();

		System.out.println("job is : " + key);
		jobdet.dataTransfer(key);

		log.info("Simplejob End................");
	
	}

}