package com.quartz.job.Services;

import java.time.Instant;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.transaction.Transactional;

import org.quartz.Job;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleTrigger;
import org.quartz.Trigger;
import org.quartz.TriggerKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.quartz.job.Entity.SchedulerJobInfo;
import com.quartz.job.Repos.SchedulerRepository;
import com.quartz.job.Scheduler.SimpleCronJob;
import com.quartz.job.Scheduler.SimpleJob;
import com.quartz.job.component.JobScheduleCreator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Transactional
@Service
public class SchedulerJobService {

	@Autowired
	private Scheduler scheduler;

	@Autowired
	private SchedulerFactoryBean schedulerFactoryBean;

	@Autowired
	private SchedulerRepository schedulerRepository;

	@Autowired
	private ApplicationContext context;

	@Autowired
	private JobScheduleCreator scheduleCreator;

	// Create, edit, pause jobs, etc...

	@PostConstruct
	public void postContruct() {
		try {

			scheduler.start();
		} catch (SchedulerException exception) {
			System.out.println("scheduler thorws exception " + exception);
		}
	}

	@PreDestroy
	public void preDestroy() {
		try {
			scheduler.shutdown();
		} catch (SchedulerException exception) {
			System.out.println("scheduler thorws exception " + exception);
		}
	}
	
	// CREATE OR UPDATE A JOB

	@SuppressWarnings("deprecation")
	public void saveOrUpdate(SchedulerJobInfo scheduleJob) throws Exception {
		if (scheduleJob.getCronExpression().length() > 0) {
			scheduleJob.setJobClass(SimpleCronJob.class.getName());
			scheduleJob.setCronJob(true);
		} else {
			scheduleJob.setJobClass(SimpleJob.class.getName());
			scheduleJob.setCronJob(false);
//			scheduleJob.setRepeatTime((long) 1);
		}
		if (StringUtils.isEmpty(scheduleJob.getJobId())) {
			log.info("Job Info: {}", scheduleJob);
			scheduleNewJob(scheduleJob);
		} else {
			updateScheduleJob(scheduleJob);
		}
		scheduleJob.setDescription("i am job number " + scheduleJob.getJobId());
		scheduleJob.setInterfaceName("interface_" + scheduleJob.getJobId());
		log.info(">>>>> jobName = [" + scheduleJob.getJobName() + "]" + " created.");
	}

	// schedule new job
	@SuppressWarnings("unchecked")
	private void scheduleNewJob(SchedulerJobInfo jobInfo) {
		try {
			Scheduler scheduler = schedulerFactoryBean.getScheduler();

			@SuppressWarnings("unchecked")
			JobDetail jobDetail = JobBuilder.newJob((Class<? extends Job>) Class.forName(jobInfo.getJobClass()))
					.withIdentity(jobInfo.getJobName(), jobInfo.getJobGroup()).build();
			if (!scheduler.checkExists(jobDetail.getKey())) {

				jobDetail = scheduleCreator.createJob(
						(Class<? extends QuartzJobBean>) Class.forName(jobInfo.getJobClass()), false, context,
						jobInfo.getJobName(), jobInfo.getJobGroup());

				Trigger trigger;
				if (jobInfo.getCronJob()) {
					trigger = scheduleCreator.createCronTrigger(
							jobInfo.getJobName(),
							jobInfo.getStartTime(),
							jobInfo.getCronExpression(), SimpleTrigger.MISFIRE_INSTRUCTION_FIRE_NOW);
				} else {
					trigger = scheduleCreator.createSimpleTrigger(
							jobInfo.getJobName(), 
							jobInfo.getStartTime(),
							jobInfo.getRepeatTime(),
							SimpleTrigger.MISFIRE_INSTRUCTION_FIRE_NOW);
				}
				scheduler.scheduleJob(jobDetail, trigger).toInstant();
				jobInfo.setJobStatus("SCHEDULED");
				schedulerRepository.save(jobInfo);
				log.info(">>>>> jobName = [" + jobInfo.getJobName() + "]" + " scheduled.");
			} else {
				log.error("scheduleNewJobRequest.jobAlreadyExist");
				updateScheduleJob(jobInfo);
			}
		} catch (ClassNotFoundException e) {
			log.error("Class Not Found - {}", jobInfo.getJobClass(), e);
		} catch (SchedulerException e) {
			log.error(e.getMessage(), e);
		}
	}

	// update job
	private void updateScheduleJob(SchedulerJobInfo jobInfo) {
		Trigger newTrigger;

		if (jobInfo.getCronJob()) {

			newTrigger = scheduleCreator.createCronTrigger(
					jobInfo.getJobName(), 
					jobInfo.getStartTime(),
					jobInfo.getCronExpression(), 
					SimpleTrigger.MISFIRE_INSTRUCTION_FIRE_NOW);
		} else {

			newTrigger = scheduleCreator.createSimpleTrigger(
					jobInfo.getJobName(),
					jobInfo.getStartTime(),
					jobInfo.getRepeatTime(),
					SimpleTrigger.MISFIRE_INSTRUCTION_FIRE_NOW);
		}
		try {
			
			Instant rescheduleJob = schedulerFactoryBean.getScheduler().rescheduleJob(TriggerKey.triggerKey(
					jobInfo.getJobName()),
					newTrigger).toInstant();
			
			
			log.info("job reshulded : "+rescheduleJob);

			SchedulerJobInfo info = schedulerRepository.findByJobName(jobInfo.getJobName());

			info.setJobStatus("EDITED & SCHEDULED");
			info.setCronExpression(jobInfo.getCronExpression());
			info.setDelete_api(jobInfo.getDelete_api());
			info.setGet_api(jobInfo.getGet_api());
			info.setPost_api(jobInfo.getPost_api());
			info.setRepeatTime(jobInfo.getRepeatTime());
			info.setStartTime(jobInfo.getStartTime());
			info.setCronJob(jobInfo.getCronJob());
			info.setToken("Bearer"+ " "+jobInfo.getToken());
			schedulerRepository.save(info);
			log.info(">>>>> jobName = [" + jobInfo.getJobName() + "]" + " updated and scheduled.");
		} catch (SchedulerException e) {
			log.error(e.getMessage(), e);
		}
	}


	// RUN A QUARTZ JOB
	public boolean startJobNow(SchedulerJobInfo jobInfo) {
		try {
			SchedulerJobInfo getJobInfo = schedulerRepository.findByJobName(jobInfo.getJobName());
			getJobInfo.setJobStatus("SCHEDULED & STARTED");
			schedulerRepository.save(getJobInfo);
			schedulerFactoryBean.getScheduler().triggerJob(new JobKey(jobInfo.getJobName(), jobInfo.getJobGroup()));
			log.info(">>>>> jobName = [" + jobInfo.getJobName() + "]" + " scheduled and started now.");
			return true;
		} catch (SchedulerException e) {
			log.error("Failed to start new job - {}", jobInfo.getJobName(), e);
			return false;
		}
	}

	// PAUSE A QUARTZ JOB
	public boolean pauseJob(SchedulerJobInfo jobInfo) {
		try {
			SchedulerJobInfo getJobInfo = schedulerRepository.findByJobName(jobInfo.getJobName());
			getJobInfo.setJobStatus("PAUSED");
			schedulerRepository.save(getJobInfo);
			schedulerFactoryBean.getScheduler().pauseJob(new JobKey(jobInfo.getJobName(), jobInfo.getJobGroup()));
			log.info(">>>>> jobName = [" + jobInfo.getJobName() + "]" + " paused.");
			return true;
		} catch (SchedulerException e) {
			log.error("Failed to pause job - {}", jobInfo.getJobName(), e);
			return false;
		}
	}

	// RESUME A QUARTZ JOB
	public boolean resumeJob(SchedulerJobInfo jobInfo) {
		try {
			SchedulerJobInfo getJobInfo = schedulerRepository.findByJobName(jobInfo.getJobName());
			getJobInfo.setJobStatus("RESUMED");
			schedulerRepository.save(getJobInfo);
			schedulerFactoryBean.getScheduler().resumeJob(new JobKey(jobInfo.getJobName(), jobInfo.getJobGroup()));
			log.info(">>>>> jobName = [" + jobInfo.getJobName() + "]" + " resumed.");
			return true;
		} catch (SchedulerException e) {
			log.error("Failed to resume job - {}", jobInfo.getJobName(), e);
			return false;
		}
	}

	// DELETE A QUARTZ JOB
	public boolean deleteJob(String jobName, SchedulerJobInfo jobInfo) {
		try {
			SchedulerJobInfo getJobInfo = schedulerRepository.findByJobName(jobName);
			schedulerRepository.delete(getJobInfo);
			log.info(">>>>> jobName = [" + jobInfo.getJobName() + "]" + " deleted.");
			return schedulerFactoryBean.getScheduler()
					.deleteJob(new JobKey(getJobInfo.getJobName(), getJobInfo.getJobGroup()));
		} catch (SchedulerException e) {
			log.error("Failed to delete job - {}", jobInfo.getJobName(), e);
			return false;
		}
	}

	// GET ALL QUARTZ JOB
	public List<SchedulerJobInfo> getall() {

		List<SchedulerJobInfo> getJobInfo = schedulerRepository.findAll();
//		        schedulerFactoryBean.getScheduler().getCurrentlyExecutingJobs();

		return getJobInfo;

	}

	// GET ALL QUARTZ JOB
	public List<JobExecutionContext> getallrunning() throws SchedulerException {
		List<JobExecutionContext> currentlyExecutingJobs = schedulerFactoryBean.getScheduler()
				.getCurrentlyExecutingJobs();

		return currentlyExecutingJobs;

	}

}