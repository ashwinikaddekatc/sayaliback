package com.quartz.job.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.quartz.job.Entity.AboutWork;
import com.quartz.job.Entity.SchedulerJobInfo;
import com.quartz.job.Repos.SchedulerRepository;

@Service
public class DataTransferJob {
	
	@Autowired
	private SchedulerRepository schedulerRepository;
	
	
	public void dataTransfer(String key) {
        SchedulerJobInfo jobinfo = schedulerRepository.findByJobName(key);

		
//		ConnectionProfile con = connectionRepo.findById(id).orElseThrow(null);
		// this method is for data transfer
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<Object> u = restTemplate.getForEntity(jobinfo.getGet_api(), Object.class);
//				  .getForEntity("http://localhost:9190/token/gettoporder", AboutWork.class);
		if (u.getBody() != null) {
			System.out.println("Getting data from Registration Backend");

			System.out.println(u.getBody());

			Object user = u.getBody();
			try {

				String resourceUrl = jobinfo.getPost_api();
//					          = "http://localhost:9191/api/addaccountcusto";

				String token =
//						"Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJTWVNBRE1JTiIsInNjb3BlcyI6IlJPTEVfU1lTQURNSU4iLCJpYXQiOjE2NjE4NTg3ODQsImV4cCI6MTY2MTg3Njc4NH0.yGyc-CWBGtBKYvtb9eaCYzDcfxhwOI8-1xvKXlSr9rw";
						jobinfo.getToken();
						HttpHeaders headers = getHeaders();
						headers.set("Authorization", token);
						HttpEntity<Object> request = new HttpEntity<Object>(user,headers);
//						
//				HttpHeaders headers = new HttpHeaders();
//				headers.setContentType(MediaType.APPLICATION_JSON);
//				HttpEntity<Object> request = new HttpEntity<Object>(user, headers);

				ResponseEntity<Void> res = restTemplate.postForEntity(resourceUrl, request, Void.class);
//					        ResponseEntity<Void> res = restTemplate.exchange(resourceUrl,HttpMethod.POST,request, Void.class);

				System.out.println("Send Data to insert in portal backend");
				
				HttpStatus s = res.getStatusCode();

				if (s.equals(HttpStatus.OK)) {
					restTemplate.delete(jobinfo.getDelete_api(), Void.class);

//							  .delete("http://localhost:9190/token/deleteaccount"+ "/"+ u.getBody().getId());
					System.out.println("Deleted data from reg");
				}

			} catch (RestClientException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		else {
			System.out.println("no data found");
		}

	}
	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return headers;
	}
	


}
