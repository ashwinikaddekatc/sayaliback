package com.realnet.Connector.Entity;

import lombok.Data;

@Data
public class Mapping {

	private String mappingString;
}
